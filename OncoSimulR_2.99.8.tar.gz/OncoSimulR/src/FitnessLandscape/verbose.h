#ifndef _VERBOSE_H_
#define _VERBOSE_H_

extern char verbose;

#endif
