#include "verbose.h"
char verbose = 0;
